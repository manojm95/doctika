import { Component, OnInit, Input } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() headerMsg: string;
  @Input() headerContent: string;
  
  userName: string;
  logout: string = "(logout)";

  constructor(private authService: AuthService, private router: Router, public oktaAuth: OktaAuthService) { }

  async ngOnInit() {
    const user = await this.oktaAuth.getUser();
    this.userName = "hi " + user.email.split("@")[0];
  }

  isAuthenticated(): boolean{
    return true;
  }

  onLogout(){
    this.oktaAuth.logout('/auth/signin');
  }

  onSaveData(){

  }

  onFetchData(){
    
  }

}
